(function($){

    $(function(){

        GRID.init();

        $.grid.menuToggle({
            breakPoint: 1024
        });

    })

})(jQuery);